var searchData=
[
  ['type',['Type',['../struct_target.html#ad5cd7a6c8019bb949937da4eb678d916',1,'Target']]]
];
