var searchData=
[
  ['name',['Name',['../struct_target.html#ab7d0d02056d1ca992da45576cc872ddf',1,'Target']]]
];
