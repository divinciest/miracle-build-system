var namespace_helpers =
[
    [ "String", "namespace_helpers_1_1_string.html", null ]
];