var searchData=
[
  ['path_5fmax_5flength',['PATH_MAX_LENGTH',['../path_8h.html#a5e37588e43efec8e8ba302ba49030177',1,'path.h']]]
];
