var namespaces_dup =
[
    [ "Helpers", "namespace_helpers.html", "namespace_helpers" ]
];