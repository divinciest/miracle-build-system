var files_dup =
[
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "path.cpp", "path_8cpp.html", "path_8cpp" ],
    [ "path.h", "path_8h.html", "path_8h" ]
];