var struct_process_console_output =
[
    [ "Clear", "struct_process_console_output.html#a4049a3758cbd070d69ac14604c761de0", null ],
    [ "GetStdError", "struct_process_console_output.html#a4d1f837604e389eca9a112704e3902d2", null ],
    [ "GetStdOut", "struct_process_console_output.html#a0c99ef0dea56cb8cbb09cf9fa9d80015", null ],
    [ "error", "struct_process_console_output.html#ad6430c543cda454a8ce71c0b4ef5f2b5", null ],
    [ "output", "struct_process_console_output.html#a7ebb81952f61c15d3c80948b1853db18", null ]
];