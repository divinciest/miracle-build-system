var indexSectionsWithContent =
{
  0: "_abcdegilmnoprstuw~",
  1: "celmpt",
  2: "mp",
  3: "abcdegilmoprstu~",
  4: "bcdegilnopstw",
  5: "_dip"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Classes",
  2: "Fichiers",
  3: "Fonctions",
  4: "Variables",
  5: "Macros"
};

