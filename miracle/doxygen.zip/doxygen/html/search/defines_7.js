var searchData=
[
  ['setter',['SETTER',['../_helpers_8hpp.html#a4fd430e669477e73c92a9e09bc34155e',1,'Helpers.hpp']]]
];
