var _helpers_8hpp =
[
    [ "__HERLPERS_HPP_INCLUDED__", "_helpers_8hpp.html#a4be36ff3e5b1fd122d042f68d761af0f", null ],
    [ "CONCAT", "_helpers_8hpp.html#a48e16e57169813404daf034bb50d5d4b", null ],
    [ "CONCAT1", "_helpers_8hpp.html#ad09f29ade9ee12013763b90d35dd1ec7", null ],
    [ "GETTER", "_helpers_8hpp.html#a1eb6ca22baee53862c9210bceb5ba75c", null ],
    [ "REF_GETTER", "_helpers_8hpp.html#a471c38a209c035c82a3da97d3abd19cc", null ],
    [ "SETTER", "_helpers_8hpp.html#a4fd430e669477e73c92a9e09bc34155e", null ],
    [ "as_string", "_helpers_8hpp.html#a0e19345860395e1f58d5debec08b9822", null ],
    [ "print", "_helpers_8hpp.html#a9f7ee8aaf17d6a59f5fce3710fd1dce9", null ],
    [ "print_note", "_helpers_8hpp.html#ac7c083b57c2f8a64f2c4500093c61a5d", null ],
    [ "RemoveSpacesFromSides", "_helpers_8hpp.html#ae94f505f387dd5abf3c686e61835cd57", null ],
    [ "ReplaceOccurences", "_helpers_8hpp.html#a456b9d85471a77aebc385db588df0b6f", null ]
];