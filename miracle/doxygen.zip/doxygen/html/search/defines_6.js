var searchData=
[
  ['ref_5fgetter',['REF_GETTER',['../_helpers_8hpp.html#a471c38a209c035c82a3da97d3abd19cc',1,'Helpers.hpp']]]
];
